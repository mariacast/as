# -*- coding: utf-8 -*-
#########################################################
# All rights by SoftPymes
# Controller Example
#########################################################

from app.exception import InternalServerError
from app.models import ExampleModel
from app import db


class ExampleController:

    @staticmethod
    def get_index():
        try:
            response = {
                'ok': True,
                'message': 'Response OK, method get_index'
            }
            return response
        except Exception as e:
            print('Error: {er}'.format(er=e))
            raise InternalServerError(e)

class RegistrosController:
    #clase para procesar la funcion de consulta de todos los registros
    @staticmethod
    def get_registros():

        data=[]
        examp = ExampleModel.query.all()
        for e in examp:
            data.append({"name":e.name,"identification":e.identification,"description":e.description,"status":e.status})
        try:
            return data
            #return response
        except Exception as e:
            print('Error: {er}'.format(er=e))
            raise InternalServerError(e)

class BuscarRegistroController:
    #clase para procesar la funcion de busqueda de un campo
    @staticmethod
    def get_buscar_registros(form):
        data=[]
        form= form

        for v in form.values():
            examp = ExampleModel.query.filter((ExampleModel.name==v) | (ExampleModel.identification==v) | (ExampleModel.description == v) | (ExampleModel.status== v))

            for e in examp:
                data.append({"name":e.name,"identification":e.identification,"description":e.description,"status":e.status})
        try:
            if data==[]:
                data = {
                    'message': 'Enviar un dato a buscar'
                }
            return data
        except Exception as e:
            print('Error: {er}'.format(er=e))
            raise InternalServerError(e)
