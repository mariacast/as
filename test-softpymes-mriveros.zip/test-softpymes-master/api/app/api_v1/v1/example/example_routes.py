# -*- coding: utf-8 -*-
#########################################################
# All rights by SoftPymes
# Routes Example
#########################################################

from flask import request, jsonify
from app.api_v1 import api
from app.controllers import ExampleController as Controller
from app.controllers import RegistrosController as ControllerRegistros
from app.controllers import BuscarRegistroController as ControllerBuscarRegistros
from app.models import BaseModel as BaseMod
from app.models import ExampleModel
from app.utils import FieldValidations

@api.route('/index', methods=['GET'])
def get_index():
    response = Controller.get_index()
    return jsonify(data=response)


@api.route("/consulta", methods = ['GET', 'POST'])
def get_registros():#funcion para ver todos los registros
    result = ControllerRegistros.get_registros()

    return jsonify(data=result)


@api.route("/buscar", methods = ['GET', 'POST'])
def get_buscar_registros():#funcion para buscar un registro por cualquier campo
    if request.method == 'POST':
        form= request.form
        result = ControllerBuscarRegistros.get_buscar_registros(form)

    else:
        result = {
            'message': 'Metodo GET no valido para esta url, ingrese campo a buscar y en metodo POST'
        }

    return jsonify(data=result)

@api.route("/delete/<id>", methods = ['DELETE'])
def get_eliminar_registros(id):#funcion para borrar un registro pasando el id
    id=id
    if request.method == 'DELETE':
        a = bool(ExampleModel.query.filter_by(id=id).first())
        if a == True:
            field = ExampleModel.query.filter_by(id=id).first()
            result = field.delete()
            if result == None:
                response = {
                    'message': 'El registrto a sido eliminado correctamente'
                }
            return jsonify(data=response)
        else:
            response = {
                'message': 'El registro a borrar no existe'
            }

        return jsonify(data=response)
    else:
        response = {
            'message': 'Error, El metodo para esta url debe ser DELETE'
        }

    return jsonify(data=response)

@api.route("/update/<id>", methods = ['PUT'])
def get_update_registros(id):#funcion para actualizar los campos de un registro
    id=id
    if request.method == 'PUT':
        a = bool(ExampleModel.query.filter_by(id=id).first())
        if a == True:
            form= request.form
            field = ExampleModel.query.get(id)

            if 'name' in form:
                field.name = request.form['name']

            if 'identification' in form:
                field.identification = request.form['identification']

            if 'description' in form:
                field.description = request.form['description']

            if 'status' in form:
                field.status = request.form['status']


            result = field.update()

            response = {
                'message': 'El registrto a sido Editado correctamente'
            }

            return jsonify(data=response)
        else:
            response = {
                'message': 'El registro a Editar no existe'
            }

        return jsonify(data=response)



@api.route("/save", methods = ['POST'])
def save_registros():#funcion para guardar un registro nuevo en la db
    if request.method == 'POST':
        registro=ExampleModel()
        form = request.form

        if 'name' in form and 'identification' in form and 'status' in form:

            name = request.form['name']
            identification=request.form['identification']
            status=request.form['status']

            if status.isdigit() and identification.isdigit():
                duplicado = bool(ExampleModel.query.filter_by(identification=identification))
                duplicados = ExampleModel.query.filter_by(identification=identification)
                for d in duplicados:
                    response = {
                        'message': 'Identification esta duplicado'
                    }
                    return jsonify(data=response)

                s=str(status)
                if len(identification) <= 10:

                    if len(s) == 1:
                        registro.name = name
                        registro.identification=identification
                        registro.status=status

                        result = registro.save()
                    else:
                        response = {
                            'message': 'El valor de status excede el numero de caracteres'
                        }
                        return jsonify(data=response)
                else:
                    response = {
                        'message': 'El valor de identification excede el los 10 caracteres'
                    }
                    return jsonify(data=response)
            else:
                response = {
                    'message': 'El valor de status y identification debe ser numerico'
                }
                return jsonify(data=response)



            registro.name = name
            registro.identification=identification
            registro.status=status

            result = registro.save()
        else:

            response = {
                'message': 'Los campos de name, identification y status son requeridos!'
            }

            return jsonify(data=response)
        response = {
            'message': 'El registro se Guardo con exito!!'
        }

        return jsonify(data=response)
