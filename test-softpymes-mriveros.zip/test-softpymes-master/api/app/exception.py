# -*- coding: utf-8 -*-
#########################################################
class InternalServerError(ValueError):
    """
    """
    pass


class NotFound(ValueError):
    """
    """
    pass


class BadRequest(ValueError):
    """
    """
    pass


class MethodNotAllowed(ValueError):
    """
    """
    pass